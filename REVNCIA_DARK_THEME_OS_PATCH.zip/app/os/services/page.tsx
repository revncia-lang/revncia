import Link from "next/link";
import { offerings } from "@/lib/catalog";
import { shell, surfaceHover } from "@/lib/ui";

export default function OSServiceCatalog() {
  return (
    <div className="min-h-[calc(100vh-72px)] bg-[radial-gradient(ellipse_70%_40%_at_70%_0%,rgba(98,217,255,.07),transparent_65%)]">
      <div className={`${shell} py-10 lg:py-14`}>
        <div className="flex flex-col justify-between gap-5 md:flex-row md:items-end">
          <div>
            <div className="text-[9px] font-semibold uppercase tracking-[0.25em] text-cyan-200/55">Services / Catalog</div>
            <h1 className="mt-3 text-4xl font-semibold tracking-[-0.035em] text-white md:text-5xl">REVNCIA Service Catalog</h1>
            <p className="mt-4 max-w-3xl text-sm leading-7 text-white/42">Every service in the shared REVNCIA catalog is available as an operating capability: assess it, request it, implement it, measure it, and move it into managed operations.</p>
          </div>
          <Link href="/os/service-requests" className="inline-flex w-fit rounded-xl border border-white/20 bg-white px-5 py-3 text-[10px] font-semibold uppercase tracking-[0.14em] text-black hover:bg-white/90">New service request →</Link>
        </div>
        <div className="mt-8 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {offerings.map((service) => (
            <Link key={service.slug} href={`/services/${service.slug}`} className={`${surfaceHover} group min-w-0 p-5`}>
              <div className="flex items-start justify-between gap-3"><span className="text-[9px] font-semibold tracking-[0.18em] text-cyan-200/60">{service.n} · {service.group}</span><span className="text-white/20 transition group-hover:text-cyan-200">↗</span></div>
              <h2 className="mt-4 text-lg font-semibold text-white">{service.name}</h2>
              <p className="mt-2 text-xs leading-6 text-white/42">{service.title}</p>
              <div className="mt-5 flex items-center justify-between border-t border-white/8 pt-3 text-[9px] uppercase tracking-[0.14em] text-white/25"><span>Stage {service.stage}</span><span>View</span></div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
