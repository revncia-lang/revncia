import { RevnciaLogo } from './RevnciaLogo';
export function WebsiteHeader() {
  return <header className="rv-header"><RevnciaLogo/><nav className="rv-nav"><a href="#solutions">Solutions</a><a href="#services">Services</a><a href="#industries">Industries</a><a href="/os">REVNCIA OS</a><a href="#ai">AI</a><a href="#company">Company</a></nav><div className="rv-header-actions"><a className="rv-link" href="/signin">Sign in</a><a className="rv-btn rv-btn-primary" href="/get-started">Get started</a></div></header>;
}
