export function RevnciaLogo() {
  return <div className="rv-logo" aria-label="REVNCIA"><span className="rv-logo-mark">R</span><span><strong>REVNCIA</strong><small>Digital Transformation & Public Impact</small></span></div>;
}
